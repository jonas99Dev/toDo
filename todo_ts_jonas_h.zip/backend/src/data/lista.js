const lista = [{ day: "monday" }, { assignment: "cleaning" }];
module.exports = lista;
