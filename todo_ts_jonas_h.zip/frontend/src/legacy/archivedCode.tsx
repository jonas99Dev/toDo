// kod som tidigare använts

// TodoForm.propTypes = {
//   existingTodo: PropTypes.shape({
//     id: PropTypes.number,
//     title: PropTypes.string.isRequired,
//     description: PropTypes.string,
//   }),
//   onSave: PropTypes.func.isRequired,
// };
// kod som tidigare använts

// från TodoItem.tsx
// PropTypes för att validera props som skickas till komponenten
// TodoItem.propTypes = {
//   todo: PropTypes.shape({
//     id: PropTypes.number.isRequired,
//     title: PropTypes.string.isRequired,
//     description: PropTypes.string,
//     is_completed: PropTypes.bool.isRequired,
//   }).isRequired,
// };
